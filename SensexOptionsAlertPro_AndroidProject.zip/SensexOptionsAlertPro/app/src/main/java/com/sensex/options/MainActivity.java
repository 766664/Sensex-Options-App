package com.sensex.options;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.webkit.*;
import android.graphics.Color;
import android.view.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_NOTIF = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    public static class Bridge {
        private final Context ctx;
        Bridge(Context c){ctx=c;}
        @JavascriptInterface public void notifyUser(String title, String body) {
            String channelId="sensex_alerts";
            NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT>=26){
                NotificationChannel ch=new NotificationChannel(channelId,"Sensex Alerts",NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT>=26
                ? new Notification.Builder(ctx,channelId)
                : new Notification.Builder(ctx);
            nb.setSmallIcon(android.R.drawable.ic_dialog_info)
              .setContentTitle(title).setContentText(body)
              .setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
            nm.notify((int)(System.currentTimeMillis()%100000), nb.build());
        }
        @JavascriptInterface public void toast(String msg){
            Toast.makeText(ctx,msg,Toast.LENGTH_SHORT).show();
        }
    }
}