Sensex Options Alert Pro - Android project

Included:
- Mobile Android WebView app UI
- Sensex CE/PE option dashboard
- Trend, reversal, top/bottom, order-block, entry, SL and target panels
- Android notification test bridge
- Angel One credential fields (credentials are not stored or sent by this demo)
- No automatic order placement

Important:
This package is a buildable Android project, not a compiled APK.
The live Angel One SmartAPI/WebSocket and server push backend still need to be connected.
Do not share your Client ID, API key, PIN or TOTP with anyone.